﻿namespace SWE.Resources
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            panel1 = new Panel();
            comboBox1 = new ComboBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox1 = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            textBox5 = new TextBox();
            comboBox6 = new ComboBox();
            comboBox4 = new ComboBox();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            dataGridView1 = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // guna2Button5
            // 
            guna2Button5.BackColor = Color.LavenderBlush;
            guna2Button5.BorderColor = Color.DarkOliveGreen;
            guna2Button5.BorderRadius = 20;
            guna2Button5.CustomizableEdges = customizableEdges7;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.LavenderBlush;
            guna2Button5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button5.ForeColor = Color.Purple;
            guna2Button5.Location = new Point(27, 9);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button5.Size = new Size(1332, 58);
            guna2Button5.TabIndex = 19;
            guna2Button5.Text = "Services";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(185, 216, 240);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(guna2HtmlLabel1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(comboBox6);
            panel1.Controls.Add(comboBox4);
            panel1.Controls.Add(guna2HtmlLabel9);
            panel1.Controls.Add(guna2HtmlLabel10);
            panel1.Controls.Add(guna2HtmlLabel11);
            panel1.Controls.Add(guna2HtmlLabel12);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(27, 73);
            panel1.Name = "panel1";
            panel1.Size = new Size(1332, 547);
            panel1.TabIndex = 18;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.LavenderBlush;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(789, 220);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(522, 28);
            comboBox1.TabIndex = 84;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Purple;
            guna2HtmlLabel1.Location = new Point(978, 181);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(55, 33);
            guna2HtmlLabel1.TabIndex = 83;
            guna2HtmlLabel1.Text = "Type";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LavenderBlush;
            textBox1.Location = new Point(789, 307);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(522, 27);
            textBox1.TabIndex = 82;
            // 
            // button4
            // 
            button4.BackColor = Color.MediumOrchid;
            button4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(1051, 469);
            button4.Name = "button4";
            button4.Size = new Size(115, 50);
            button4.TabIndex = 81;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumOrchid;
            button3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(913, 469);
            button3.Name = "button3";
            button3.Size = new Size(120, 50);
            button3.TabIndex = 80;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.MediumOrchid;
            button2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(772, 469);
            button2.Name = "button2";
            button2.Size = new Size(122, 50);
            button2.TabIndex = 79;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumOrchid;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(1191, 469);
            button1.Name = "button1";
            button1.Size = new Size(120, 50);
            button1.TabIndex = 78;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.LavenderBlush;
            textBox5.Location = new Point(789, 404);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(522, 27);
            textBox5.TabIndex = 77;
            // 
            // comboBox6
            // 
            comboBox6.BackColor = Color.LavenderBlush;
            comboBox6.FormattingEnabled = true;
            comboBox6.Location = new Point(789, 134);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(522, 28);
            comboBox6.TabIndex = 76;
            // 
            // comboBox4
            // 
            comboBox4.BackColor = Color.LavenderBlush;
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(789, 61);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(522, 28);
            comboBox4.TabIndex = 74;
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel9.ForeColor = Color.Purple;
            guna2HtmlLabel9.Location = new Point(922, 95);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(177, 33);
            guna2HtmlLabel9.TabIndex = 73;
            guna2HtmlLabel9.Text = "Customer Name";
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.BackColor = Color.Transparent;
            guna2HtmlLabel10.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel10.ForeColor = Color.Purple;
            guna2HtmlLabel10.Location = new Point(954, 268);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(126, 33);
            guna2HtmlLabel10.TabIndex = 72;
            guna2HtmlLabel10.Text = "Description";
            // 
            // guna2HtmlLabel11
            // 
            guna2HtmlLabel11.BackColor = Color.Transparent;
            guna2HtmlLabel11.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel11.ForeColor = Color.Purple;
            guna2HtmlLabel11.Location = new Point(954, 365);
            guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            guna2HtmlLabel11.Size = new Size(131, 33);
            guna2HtmlLabel11.TabIndex = 71;
            guna2HtmlLabel11.Text = "Service Cost";
            // 
            // guna2HtmlLabel12
            // 
            guna2HtmlLabel12.BackColor = Color.Transparent;
            guna2HtmlLabel12.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel12.ForeColor = Color.Purple;
            guna2HtmlLabel12.Location = new Point(942, 22);
            guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            guna2HtmlLabel12.Size = new Size(108, 33);
            guna2HtmlLabel12.TabIndex = 70;
            guna2HtmlLabel12.Text = "Service ID";
            guna2HtmlLabel12.Click += guna2HtmlLabel12_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.LavenderBlush;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(747, 541);
            dataGridView1.TabIndex = 0;
            // 
            // Services
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(199, 182, 209);
            ClientSize = new Size(1392, 632);
            Controls.Add(guna2Button5);
            Controls.Add(panel1);
            Name = "Services";
            Text = "Services";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Panel panel1;
        private TextBox textBox1;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private ComboBox comboBox6;
        private ComboBox comboBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private DataGridView dataGridView1;
        private ComboBox comboBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private TextBox textBox5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
    }
}