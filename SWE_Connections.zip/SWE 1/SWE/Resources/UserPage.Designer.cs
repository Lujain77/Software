﻿namespace SWE.Resources
{
    partial class UserPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel2 = new Panel();
            dateTimePicker3 = new DateTimePicker();
            guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            textBox6 = new TextBox();
            guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            comboBox6 = new ComboBox();
            comboBox5 = new ComboBox();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            dateTimePicker2 = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            textBox4 = new TextBox();
            comboBox2 = new ComboBox();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            comboBox1 = new ComboBox();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox1 = new TextBox();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(185, 216, 240);
            panel2.Controls.Add(dateTimePicker3);
            panel2.Controls.Add(guna2HtmlLabel14);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(textBox6);
            panel2.Controls.Add(guna2HtmlLabel13);
            panel2.Controls.Add(comboBox6);
            panel2.Controls.Add(comboBox5);
            panel2.Controls.Add(guna2HtmlLabel9);
            panel2.Controls.Add(guna2HtmlLabel12);
            panel2.Controls.Add(dateTimePicker2);
            panel2.Controls.Add(dateTimePicker1);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(guna2HtmlLabel2);
            panel2.Controls.Add(guna2HtmlLabel6);
            panel2.Controls.Add(guna2HtmlLabel8);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(guna2HtmlLabel7);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(guna2HtmlLabel5);
            panel2.Controls.Add(guna2HtmlLabel4);
            panel2.Controls.Add(guna2HtmlLabel3);
            panel2.Controls.Add(guna2HtmlLabel1);
            panel2.Location = new Point(12, 135);
            panel2.Name = "panel2";
            panel2.Size = new Size(1209, 534);
            panel2.TabIndex = 4;
            // 
            // dateTimePicker3
            // 
            dateTimePicker3.CalendarMonthBackground = Color.LightYellow;
            dateTimePicker3.Location = new Point(900, 80);
            dateTimePicker3.Name = "dateTimePicker3";
            dateTimePicker3.Size = new Size(262, 27);
            dateTimePicker3.TabIndex = 75;
            // 
            // guna2HtmlLabel14
            // 
            guna2HtmlLabel14.BackColor = Color.Transparent;
            guna2HtmlLabel14.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel14.ForeColor = Color.Purple;
            guna2HtmlLabel14.Location = new Point(608, 80);
            guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            guna2HtmlLabel14.Size = new Size(275, 33);
            guna2HtmlLabel14.TabIndex = 74;
            guna2HtmlLabel14.Text = "Expected Date Check Out";
            // 
            // button4
            // 
            button4.BackColor = Color.PaleGoldenrod;
            button4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(735, 471);
            button4.Name = "button4";
            button4.Size = new Size(388, 50);
            button4.TabIndex = 73;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.PaleVioletRed;
            button3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(735, 332);
            button3.Name = "button3";
            button3.Size = new Size(388, 50);
            button3.TabIndex = 72;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.LightGreen;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(735, 403);
            button1.Name = "button1";
            button1.Size = new Size(388, 50);
            button1.TabIndex = 70;
            button1.Text = "Register";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.LavenderBlush;
            textBox6.Location = new Point(767, 283);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(395, 27);
            textBox6.TabIndex = 69;
            // 
            // guna2HtmlLabel13
            // 
            guna2HtmlLabel13.BackColor = Color.Transparent;
            guna2HtmlLabel13.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel13.ForeColor = Color.Purple;
            guna2HtmlLabel13.Location = new Point(608, 283);
            guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            guna2HtmlLabel13.Size = new Size(133, 33);
            guna2HtmlLabel13.TabIndex = 68;
            guna2HtmlLabel13.Text = "promo Code";
            // 
            // comboBox6
            // 
            comboBox6.BackColor = Color.LavenderBlush;
            comboBox6.FormattingEnabled = true;
            comboBox6.Location = new Point(756, 145);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(406, 28);
            comboBox6.TabIndex = 66;
            // 
            // comboBox5
            // 
            comboBox5.BackColor = Color.LavenderBlush;
            comboBox5.FormattingEnabled = true;
            comboBox5.Location = new Point(831, 210);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(331, 28);
            comboBox5.TabIndex = 65;
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel9.ForeColor = Color.Purple;
            guna2HtmlLabel9.Location = new Point(608, 140);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(123, 33);
            guna2HtmlLabel9.TabIndex = 63;
            guna2HtmlLabel9.Text = "Room Type";
            // 
            // guna2HtmlLabel12
            // 
            guna2HtmlLabel12.BackColor = Color.Transparent;
            guna2HtmlLabel12.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel12.ForeColor = Color.Purple;
            guna2HtmlLabel12.Location = new Point(608, 210);
            guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            guna2HtmlLabel12.Size = new Size(197, 33);
            guna2HtmlLabel12.TabIndex = 60;
            guna2HtmlLabel12.Text = "Number of perons ";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.CalendarMonthBackground = Color.LightYellow;
            dateTimePicker2.Location = new Point(777, 19);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(290, 27);
            dateTimePicker2.TabIndex = 58;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(178, 289);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(290, 27);
            dateTimePicker1.TabIndex = 57;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.LavenderBlush;
            textBox4.Location = new Point(162, 369);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(355, 27);
            textBox4.TabIndex = 48;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.LavenderBlush;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(120, 442);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(397, 28);
            comboBox2.TabIndex = 47;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel2.ForeColor = Color.Purple;
            guna2HtmlLabel2.Location = new Point(608, 13);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(153, 33);
            guna2HtmlLabel2.TabIndex = 46;
            guna2HtmlLabel2.Text = "Check In Date";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel6.ForeColor = Color.Purple;
            guna2HtmlLabel6.Location = new Point(11, 363);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(129, 33);
            guna2HtmlLabel6.TabIndex = 45;
            guna2HtmlLabel6.Text = "National ID";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel8.ForeColor = Color.Purple;
            guna2HtmlLabel8.Location = new Point(11, 442);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(88, 33);
            guna2HtmlLabel8.TabIndex = 44;
            guna2HtmlLabel8.Text = "Address";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.LavenderBlush;
            textBox3.Location = new Point(162, 146);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(339, 27);
            textBox3.TabIndex = 43;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.LavenderBlush;
            textBox2.Location = new Point(196, 80);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(339, 27);
            textBox2.TabIndex = 42;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.LavenderBlush;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(107, 210);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(348, 28);
            comboBox1.TabIndex = 41;
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel7.ForeColor = Color.Purple;
            guna2HtmlLabel7.Location = new Point(11, 283);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(143, 33);
            guna2HtmlLabel7.TabIndex = 40;
            guna2HtmlLabel7.Text = "Date of Birth";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LavenderBlush;
            textBox1.Location = new Point(97, 13);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(339, 27);
            textBox1.TabIndex = 39;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel5.ForeColor = Color.Purple;
            guna2HtmlLabel5.Location = new Point(11, 74);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(170, 33);
            guna2HtmlLabel5.TabIndex = 38;
            guna2HtmlLabel5.Text = "Mobile Number";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel4.ForeColor = Color.Purple;
            guna2HtmlLabel4.Location = new Point(11, 140);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(127, 33);
            guna2HtmlLabel4.TabIndex = 37;
            guna2HtmlLabel4.Text = "Nationality";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel3.ForeColor = Color.Purple;
            guna2HtmlLabel3.Location = new Point(11, 210);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(80, 33);
            guna2HtmlLabel3.TabIndex = 36;
            guna2HtmlLabel3.Text = "Gender";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Purple;
            guna2HtmlLabel1.Location = new Point(11, 7);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(68, 33);
            guna2HtmlLabel1.TabIndex = 35;
            guna2HtmlLabel1.Text = "Name";
            // 
            // guna2Button1
            // 
            guna2Button1.BackColor = Color.LavenderBlush;
            guna2Button1.BorderRadius = 20;
            guna2Button1.CustomizableEdges = customizableEdges3;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.LavenderBlush;
            guna2Button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.Purple;
            guna2Button1.Location = new Point(12, 12);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button1.Size = new Size(1209, 117);
            guna2Button1.TabIndex = 9;
            guna2Button1.Text = "Registeration";
            // 
            // UserPage
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(199, 182, 209);
            ClientSize = new Size(1230, 681);
            Controls.Add(guna2Button1);
            Controls.Add(panel2);
            Name = "UserPage";
            Text = "UserPage";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private DateTimePicker dateTimePicker3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Button button4;
        private Button button3;
        private Button button1;
        private TextBox textBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private ComboBox comboBox6;
        private ComboBox comboBox5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox4;
        private ComboBox comboBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private TextBox textBox3;
        private TextBox textBox2;
        private ComboBox comboBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private TextBox textBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}