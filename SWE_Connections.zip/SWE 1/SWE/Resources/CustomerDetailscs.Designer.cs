﻿namespace SWE.Resources
{
    partial class Customer_Detailscs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Button5
            // 
            this.guna2Button5.BackColor = System.Drawing.Color.LavenderBlush;
            this.guna2Button5.BorderColor = System.Drawing.Color.DarkOliveGreen;
            this.guna2Button5.BorderRadius = 20;
            this.guna2Button5.CustomizableEdges = customizableEdges3;
            this.guna2Button5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button5.FillColor = System.Drawing.Color.LavenderBlush;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.guna2Button5.ForeColor = System.Drawing.Color.Purple;
            this.guna2Button5.Location = new System.Drawing.Point(33, 21);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges4;
            this.guna2Button5.Size = new System.Drawing.Size(1355, 58);
            this.guna2Button5.TabIndex = 22;
            this.guna2Button5.Text = "Customer Details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 194);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(1355, 439);
            this.dataGridView1.TabIndex = 23;
            // 
            // comboBox4
            // 
            this.comboBox4.BackColor = System.Drawing.Color.Lavender;
            this.comboBox4.Font = new System.Drawing.Font("Segoe UI", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(156, 151);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(1032, 31);
            this.comboBox4.TabIndex = 77;
            this.comboBox4.Text = "ID";
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.Purple;
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(637, 112);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(119, 33);
            this.guna2HtmlLabel12.TabIndex = 75;
            this.guna2HtmlLabel12.Text = "Search by : ";
            // 
            // Customer_Detailscs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(182)))), ((int)(((byte)(209)))));
            this.ClientSize = new System.Drawing.Size(1420, 664);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.guna2HtmlLabel12);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2Button5);
            this.Name = "Customer_Detailscs";
            this.Text = "Customer_Detailscs";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private DataGridView dataGridView1;
        private ComboBox comboBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
    }
}