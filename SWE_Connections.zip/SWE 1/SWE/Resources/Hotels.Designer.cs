﻿namespace SWE.Resources
{
    partial class Hotels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            panel1 = new Panel();
            button6 = new Button();
            button5 = new Button();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            comboBox2 = new ComboBox();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            comboBox3 = new ComboBox();
            comboBox5 = new ComboBox();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox1 = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2Button5
            // 
            guna2Button5.BackColor = Color.LavenderBlush;
            guna2Button5.BorderColor = Color.DarkOliveGreen;
            guna2Button5.BorderRadius = 20;
            guna2Button5.CustomizableEdges = customizableEdges1;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.LavenderBlush;
            guna2Button5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button5.ForeColor = Color.Purple;
            guna2Button5.Location = new Point(12, 16);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button5.Size = new Size(1340, 58);
            guna2Button5.TabIndex = 21;
            guna2Button5.Text = "Hotels";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(185, 216, 240);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(comboBox2);
            panel1.Controls.Add(guna2HtmlLabel2);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(comboBox3);
            panel1.Controls.Add(comboBox5);
            panel1.Controls.Add(guna2HtmlLabel3);
            panel1.Controls.Add(guna2HtmlLabel4);
            panel1.Controls.Add(guna2HtmlLabel5);
            panel1.Controls.Add(guna2HtmlLabel6);
            panel1.Controls.Add(guna2HtmlLabel1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(guna2HtmlLabel9);
            panel1.Controls.Add(guna2HtmlLabel10);
            panel1.Location = new Point(12, 80);
            panel1.Name = "panel1";
            panel1.Size = new Size(1340, 547);
            panel1.TabIndex = 20;
            // 
            // button6
            // 
            button6.BackColor = Color.MediumPurple;
            button6.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            button6.Location = new Point(922, 465);
            button6.Name = "button6";
            button6.Size = new Size(316, 50);
            button6.TabIndex = 98;
            button6.Text = "Create a report";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.MediumOrchid;
            button5.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button5.Location = new Point(861, 370);
            button5.Name = "button5";
            button5.Size = new Size(450, 50);
            button5.TabIndex = 97;
            button5.Text = "Total Employees : ";
            button5.UseVisualStyleBackColor = false;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.LavenderBlush;
            textBox5.Location = new Point(375, 423);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(330, 27);
            textBox5.TabIndex = 96;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.LavenderBlush;
            textBox4.Location = new Point(375, 301);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(330, 27);
            textBox4.TabIndex = 95;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.LavenderBlush;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(375, 180);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(330, 28);
            comboBox2.TabIndex = 94;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel2.ForeColor = Color.Purple;
            guna2HtmlLabel2.Location = new Point(112, 370);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(74, 33);
            guna2HtmlLabel2.TabIndex = 93;
            guna2HtmlLabel2.Text = "Adress";
            guna2HtmlLabel2.Click += guna2HtmlLabel2_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.LavenderBlush;
            textBox2.Location = new Point(19, 181);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(286, 27);
            textBox2.TabIndex = 92;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.LavenderBlush;
            textBox3.Location = new Point(19, 301);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(286, 27);
            textBox3.TabIndex = 91;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // comboBox3
            // 
            comboBox3.BackColor = Color.LavenderBlush;
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(375, 61);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(330, 28);
            comboBox3.TabIndex = 90;
            comboBox3.SelectedIndexChanged += comboBox3_SelectedIndexChanged;
            // 
            // comboBox5
            // 
            comboBox5.BackColor = Color.LavenderBlush;
            comboBox5.FormattingEnabled = true;
            comboBox5.Location = new Point(19, 61);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(286, 28);
            comboBox5.TabIndex = 89;
            comboBox5.SelectedIndexChanged += comboBox5_SelectedIndexChanged;
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel3.ForeColor = Color.Purple;
            guna2HtmlLabel3.Location = new Point(75, 129);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(170, 33);
            guna2HtmlLabel3.TabIndex = 88;
            guna2HtmlLabel3.Text = "Mobile Number";
            guna2HtmlLabel3.Click += guna2HtmlLabel3_Click;
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel4.ForeColor = Color.Purple;
            guna2HtmlLabel4.Location = new Point(112, 251);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(64, 33);
            guna2HtmlLabel4.TabIndex = 87;
            guna2HtmlLabel4.Text = "Email";
            guna2HtmlLabel4.Click += guna2HtmlLabel4_Click;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel5.ForeColor = Color.Purple;
            guna2HtmlLabel5.Location = new Point(450, 22);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(99, 33);
            guna2HtmlLabel5.TabIndex = 86;
            guna2HtmlLabel5.Text = "Capacity";
            guna2HtmlLabel5.Click += guna2HtmlLabel5_Click;
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel6.ForeColor = Color.Purple;
            guna2HtmlLabel6.Location = new Point(91, 22);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(133, 33);
            guna2HtmlLabel6.TabIndex = 85;
            guna2HtmlLabel6.Text = "Hotel Name";
            guna2HtmlLabel6.Click += guna2HtmlLabel6_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Purple;
            guna2HtmlLabel1.Location = new Point(451, 251);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(98, 33);
            guna2HtmlLabel1.TabIndex = 83;
            guna2HtmlLabel1.Text = "Zip Code";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LavenderBlush;
            textBox1.Location = new Point(19, 423);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(286, 27);
            textBox1.TabIndex = 82;
            // 
            // button4
            // 
            button4.BackColor = Color.MediumOrchid;
            button4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(861, 144);
            button4.Name = "button4";
            button4.Size = new Size(450, 50);
            button4.TabIndex = 81;
            button4.Text = "Total Rooms :";
            button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumOrchid;
            button3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(861, 39);
            button3.Name = "button3";
            button3.Size = new Size(450, 50);
            button3.TabIndex = 80;
            button3.Text = "Total Bookings : ";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.MediumOrchid;
            button2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(102, 479);
            button2.Name = "button2";
            button2.Size = new Size(485, 50);
            button2.TabIndex = 79;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumOrchid;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(861, 251);
            button1.Name = "button1";
            button1.Size = new Size(450, 50);
            button1.TabIndex = 78;
            button1.Text = "Total Money :";
            button1.UseVisualStyleBackColor = false;
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel9.ForeColor = Color.Purple;
            guna2HtmlLabel9.Location = new Point(450, 129);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(89, 33);
            guna2HtmlLabel9.TabIndex = 73;
            guna2HtmlLabel9.Text = "Country";
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.BackColor = Color.Transparent;
            guna2HtmlLabel10.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel10.ForeColor = Color.Purple;
            guna2HtmlLabel10.Location = new Point(451, 370);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(126, 33);
            guna2HtmlLabel10.TabIndex = 72;
            guna2HtmlLabel10.Text = "Description";
            // 
            // Hotels
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(199, 182, 209);
            ClientSize = new Size(1374, 642);
            Controls.Add(guna2Button5);
            Controls.Add(panel1);
            Name = "Hotels";
            Text = "Hotels";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Panel panel1;
        private ComboBox comboBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private TextBox textBox2;
        private TextBox textBox3;
        private ComboBox comboBox3;
        private ComboBox comboBox5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private TextBox textBox1;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Button button6;
        private Button button5;
        private TextBox textBox5;
        private TextBox textBox4;
    }
}