﻿namespace SWE
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            panel2 = new Panel();
            dateTimePicker3 = new DateTimePicker();
            guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            textBox6 = new TextBox();
            guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox5 = new TextBox();
            comboBox6 = new ComboBox();
            comboBox5 = new ComboBox();
            comboBox4 = new ComboBox();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            dateTimePicker2 = new DateTimePicker();
            dateTimePicker1 = new DateTimePicker();
            textBox4 = new TextBox();
            comboBox2 = new ComboBox();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            comboBox1 = new ComboBox();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            textBox1 = new TextBox();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(185, 216, 240);
            panel1.Controls.Add(guna2Button8);
            panel1.Controls.Add(guna2Button7);
            panel1.Controls.Add(guna2Button6);
            panel1.Controls.Add(guna2Button5);
            panel1.Controls.Add(guna2Button4);
            panel1.Controls.Add(guna2Button3);
            panel1.Controls.Add(guna2Button2);
            panel1.Controls.Add(guna2Button1);
            panel1.Location = new Point(50, 9);
            panel1.Name = "panel1";
            panel1.Size = new Size(1418, 118);
            panel1.TabIndex = 1;
            // 
            // guna2Button8
            // 
            guna2Button8.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button8.BorderColor = Color.DarkOliveGreen;
            guna2Button8.BorderRadius = 20;
            guna2Button8.CustomizableEdges = customizableEdges17;
            guna2Button8.DisabledState.BorderColor = Color.DarkGray;
            guna2Button8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button8.FillColor = Color.LavenderBlush;
            guna2Button8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button8.ForeColor = Color.Purple;
            guna2Button8.Location = new Point(1244, 17);
            guna2Button8.Name = "guna2Button8";
            guna2Button8.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2Button8.Size = new Size(153, 85);
            guna2Button8.TabIndex = 19;
            guna2Button8.Text = "Services";
            // 
            // guna2Button7
            // 
            guna2Button7.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button7.BorderColor = Color.DarkOliveGreen;
            guna2Button7.BorderRadius = 20;
            guna2Button7.CustomizableEdges = customizableEdges19;
            guna2Button7.DisabledState.BorderColor = Color.DarkGray;
            guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button7.FillColor = Color.LavenderBlush;
            guna2Button7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button7.ForeColor = Color.Purple;
            guna2Button7.Location = new Point(1085, 17);
            guna2Button7.Name = "guna2Button7";
            guna2Button7.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Button7.Size = new Size(153, 85);
            guna2Button7.TabIndex = 18;
            guna2Button7.Text = "Hotels";
            // 
            // guna2Button6
            // 
            guna2Button6.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button6.BorderColor = Color.DarkOliveGreen;
            guna2Button6.BorderRadius = 20;
            guna2Button6.CustomizableEdges = customizableEdges21;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.FillColor = Color.LavenderBlush;
            guna2Button6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button6.ForeColor = Color.Purple;
            guna2Button6.Location = new Point(926, 17);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2Button6.Size = new Size(153, 85);
            guna2Button6.TabIndex = 17;
            guna2Button6.Text = "Employees";
            // 
            // guna2Button5
            // 
            guna2Button5.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button5.BorderColor = Color.DarkOliveGreen;
            guna2Button5.BorderRadius = 20;
            guna2Button5.CustomizableEdges = customizableEdges23;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.LavenderBlush;
            guna2Button5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button5.ForeColor = Color.Purple;
            guna2Button5.Location = new Point(767, 17);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges24;
            guna2Button5.Size = new Size(153, 85);
            guna2Button5.TabIndex = 16;
            guna2Button5.Text = "Discount";
            // 
            // guna2Button4
            // 
            guna2Button4.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button4.BorderColor = Color.DarkOliveGreen;
            guna2Button4.BorderRadius = 20;
            guna2Button4.CustomizableEdges = customizableEdges25;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.FillColor = Color.LavenderBlush;
            guna2Button4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button4.ForeColor = Color.Purple;
            guna2Button4.Location = new Point(594, 17);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2Button4.Size = new Size(167, 85);
            guna2Button4.TabIndex = 11;
            guna2Button4.Text = "Check Out";
            // 
            // guna2Button3
            // 
            guna2Button3.BorderRadius = 20;
            guna2Button3.CustomizableEdges = customizableEdges27;
            guna2Button3.DisabledState.BorderColor = Color.DarkGray;
            guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button3.FillColor = Color.LavenderBlush;
            guna2Button3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button3.ForeColor = Color.Purple;
            guna2Button3.Location = new Point(388, 17);
            guna2Button3.Name = "guna2Button3";
            guna2Button3.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2Button3.Size = new Size(200, 85);
            guna2Button3.TabIndex = 10;
            guna2Button3.Text = "Customer Detalis";
            // 
            // guna2Button2
            // 
            guna2Button2.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button2.BorderRadius = 20;
            guna2Button2.CustomizableEdges = customizableEdges29;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.LavenderBlush;
            guna2Button2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button2.ForeColor = Color.Purple;
            guna2Button2.Location = new Point(206, 17);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges30;
            guna2Button2.Size = new Size(176, 85);
            guna2Button2.TabIndex = 9;
            guna2Button2.Text = "Add Room";
            guna2Button2.Click += guna2Button2_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.BackColor = Color.FromArgb(185, 216, 240);
            guna2Button1.BorderRadius = 20;
            guna2Button1.CustomizableEdges = customizableEdges31;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.LavenderBlush;
            guna2Button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.Purple;
            guna2Button1.Location = new Point(11, 17);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges32;
            guna2Button1.Size = new Size(189, 85);
            guna2Button1.TabIndex = 8;
            guna2Button1.Text = "Customer Registeration";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(185, 216, 240);
            panel2.Controls.Add(dateTimePicker3);
            panel2.Controls.Add(guna2HtmlLabel14);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(textBox6);
            panel2.Controls.Add(guna2HtmlLabel13);
            panel2.Controls.Add(textBox5);
            panel2.Controls.Add(comboBox6);
            panel2.Controls.Add(comboBox5);
            panel2.Controls.Add(comboBox4);
            panel2.Controls.Add(guna2HtmlLabel9);
            panel2.Controls.Add(guna2HtmlLabel10);
            panel2.Controls.Add(guna2HtmlLabel11);
            panel2.Controls.Add(guna2HtmlLabel12);
            panel2.Controls.Add(dateTimePicker2);
            panel2.Controls.Add(dateTimePicker1);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(guna2HtmlLabel2);
            panel2.Controls.Add(guna2HtmlLabel6);
            panel2.Controls.Add(guna2HtmlLabel8);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(comboBox1);
            panel2.Controls.Add(guna2HtmlLabel7);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(guna2HtmlLabel5);
            panel2.Controls.Add(guna2HtmlLabel4);
            panel2.Controls.Add(guna2HtmlLabel3);
            panel2.Controls.Add(guna2HtmlLabel1);
            panel2.Location = new Point(50, 144);
            panel2.Name = "panel2";
            panel2.Size = new Size(1418, 534);
            panel2.TabIndex = 2;
            // 
            // dateTimePicker3
            // 
            dateTimePicker3.CalendarMonthBackground = Color.LightYellow;
            dateTimePicker3.Location = new Point(541, 389);
            dateTimePicker3.Name = "dateTimePicker3";
            dateTimePicker3.Size = new Size(262, 27);
            dateTimePicker3.TabIndex = 75;
            // 
            // guna2HtmlLabel14
            // 
            guna2HtmlLabel14.BackColor = Color.Transparent;
            guna2HtmlLabel14.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel14.ForeColor = Color.Purple;
            guna2HtmlLabel14.Location = new Point(541, 327);
            guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            guna2HtmlLabel14.Size = new Size(275, 33);
            guna2HtmlLabel14.TabIndex = 74;
            guna2HtmlLabel14.Text = "Expected Date Check Out";
            // 
            // button4
            // 
            button4.BackColor = Color.MediumOrchid;
            button4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(688, 472);
            button4.Name = "button4";
            button4.Size = new Size(115, 50);
            button4.TabIndex = 73;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumOrchid;
            button3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(550, 472);
            button3.Name = "button3";
            button3.Size = new Size(120, 50);
            button3.TabIndex = 72;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.MediumOrchid;
            button2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(409, 472);
            button2.Name = "button2";
            button2.Size = new Size(122, 50);
            button2.TabIndex = 71;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumOrchid;
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(821, 472);
            button1.Name = "button1";
            button1.Size = new Size(120, 50);
            button1.TabIndex = 70;
            button1.Text = "Register";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.LavenderBlush;
            textBox6.Location = new Point(1055, 495);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(262, 27);
            textBox6.TabIndex = 69;
            // 
            // guna2HtmlLabel13
            // 
            guna2HtmlLabel13.BackColor = Color.Transparent;
            guna2HtmlLabel13.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel13.ForeColor = Color.Purple;
            guna2HtmlLabel13.Location = new Point(1055, 442);
            guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            guna2HtmlLabel13.Size = new Size(133, 33);
            guna2HtmlLabel13.TabIndex = 68;
            guna2HtmlLabel13.Text = "promo Code";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.LavenderBlush;
            textBox5.Location = new Point(1055, 382);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(262, 27);
            textBox5.TabIndex = 67;
            // 
            // comboBox6
            // 
            comboBox6.BackColor = Color.LavenderBlush;
            comboBox6.FormattingEnabled = true;
            comboBox6.Location = new Point(1055, 162);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(262, 28);
            comboBox6.TabIndex = 66;
            // 
            // comboBox5
            // 
            comboBox5.BackColor = Color.LavenderBlush;
            comboBox5.FormattingEnabled = true;
            comboBox5.Location = new Point(1055, 271);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(262, 28);
            comboBox5.TabIndex = 65;
            // 
            // comboBox4
            // 
            comboBox4.BackColor = Color.LavenderBlush;
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(1055, 59);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(262, 28);
            comboBox4.TabIndex = 64;
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel9.ForeColor = Color.Purple;
            guna2HtmlLabel9.Location = new Point(1055, 123);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(123, 33);
            guna2HtmlLabel9.TabIndex = 63;
            guna2HtmlLabel9.Text = "Room Type";
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.BackColor = Color.Transparent;
            guna2HtmlLabel10.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel10.ForeColor = Color.Purple;
            guna2HtmlLabel10.Location = new Point(1055, 229);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(159, 33);
            guna2HtmlLabel10.TabIndex = 62;
            guna2HtmlLabel10.Text = "Room Number";
            // 
            // guna2HtmlLabel11
            // 
            guna2HtmlLabel11.BackColor = Color.Transparent;
            guna2HtmlLabel11.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel11.ForeColor = Color.Purple;
            guna2HtmlLabel11.Location = new Point(1055, 343);
            guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            guna2HtmlLabel11.Size = new Size(56, 33);
            guna2HtmlLabel11.TabIndex = 61;
            guna2HtmlLabel11.Text = "Price";
            // 
            // guna2HtmlLabel12
            // 
            guna2HtmlLabel12.BackColor = Color.Transparent;
            guna2HtmlLabel12.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel12.ForeColor = Color.Purple;
            guna2HtmlLabel12.Location = new Point(1055, 23);
            guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            guna2HtmlLabel12.Size = new Size(44, 33);
            guna2HtmlLabel12.TabIndex = 60;
            guna2HtmlLabel12.Text = "Bed";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.CalendarMonthBackground = Color.LightYellow;
            dateTimePicker2.Location = new Point(541, 269);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(262, 27);
            dateTimePicker2.TabIndex = 58;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(43, 462);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(339, 27);
            dateTimePicker1.TabIndex = 57;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.LavenderBlush;
            textBox4.Location = new Point(541, 60);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(262, 27);
            textBox4.TabIndex = 48;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.LavenderBlush;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(541, 166);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(262, 28);
            comboBox2.TabIndex = 47;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel2.ForeColor = Color.Purple;
            guna2HtmlLabel2.Location = new Point(541, 230);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(153, 33);
            guna2HtmlLabel2.TabIndex = 46;
            guna2HtmlLabel2.Text = "Check In Date";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel6.ForeColor = Color.Purple;
            guna2HtmlLabel6.Location = new Point(541, 19);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(129, 33);
            guna2HtmlLabel6.TabIndex = 45;
            guna2HtmlLabel6.Text = "National ID";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel8.ForeColor = Color.Purple;
            guna2HtmlLabel8.Location = new Point(541, 126);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(88, 33);
            guna2HtmlLabel8.TabIndex = 44;
            guna2HtmlLabel8.Text = "Address";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.LavenderBlush;
            textBox3.Location = new Point(43, 268);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(339, 27);
            textBox3.TabIndex = 43;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.LavenderBlush;
            textBox2.Location = new Point(43, 157);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(339, 27);
            textBox2.TabIndex = 42;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.LavenderBlush;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(43, 366);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(339, 28);
            comboBox1.TabIndex = 41;
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel7.ForeColor = Color.Purple;
            guna2HtmlLabel7.Location = new Point(120, 423);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(143, 33);
            guna2HtmlLabel7.TabIndex = 40;
            guna2HtmlLabel7.Text = "Date of Birth";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LavenderBlush;
            textBox1.Location = new Point(43, 46);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(339, 27);
            textBox1.TabIndex = 39;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel5.ForeColor = Color.Purple;
            guna2HtmlLabel5.Location = new Point(120, 107);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(170, 33);
            guna2HtmlLabel5.TabIndex = 38;
            guna2HtmlLabel5.Text = "Mobile Number";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel4.ForeColor = Color.Purple;
            guna2HtmlLabel4.Location = new Point(120, 219);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(127, 33);
            guna2HtmlLabel4.TabIndex = 37;
            guna2HtmlLabel4.Text = "Nationality";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel3.ForeColor = Color.Purple;
            guna2HtmlLabel3.Location = new Point(120, 327);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(80, 33);
            guna2HtmlLabel3.TabIndex = 36;
            guna2HtmlLabel3.Text = "Gender";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Purple;
            guna2HtmlLabel1.Location = new Point(174, 10);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(68, 33);
            guna2HtmlLabel1.TabIndex = 35;
            guna2HtmlLabel1.Text = "Name";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(199, 182, 209);
            ClientSize = new Size(1341, 710);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form3";
            Text = "Form3";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private DateTimePicker dateTimePicker2;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox4;
        private ComboBox comboBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private TextBox textBox3;
        private TextBox textBox2;
        private ComboBox comboBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private TextBox textBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private TextBox textBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private TextBox textBox5;
        private ComboBox comboBox6;
        private ComboBox comboBox5;
        private ComboBox comboBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private DateTimePicker dateTimePicker3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
    }
}