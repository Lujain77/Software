using MySql.Data.MySqlClient;

namespace SWE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {

        }

        private void guna2ImageButton2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string MyConnection2 = "datasource=localhost;port=3307;username=root;password=root";
                string Query = "SELECT * FROM sign_up WHERE name = @username AND password = @password";

                using (MySqlConnection MyConn2 = new MySqlConnection(MyConnection2))
                {
                    using (MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2))
                    {
                        MyCommand2.Parameters.AddWithValue("@username", textBox1.Text);
                        MyCommand2.Parameters.AddWithValue("@password", textBox2.Text);

                        MyConn2.Open();

                        using (MySqlDataReader MyReader2 = MyCommand2.ExecuteReader())
                        {
                            // Check if any rows are returned
                            if (MyReader2.Read())
                            {
                                // Credentials are correct
                                MessageBox.Show("Login successful!");
                            }
                            else
                            {
                                // Credentials are incorrect
                                MessageBox.Show("Invalid username or password");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string MyConnection2 = "datasource=localhost;port=3307;username=root;password=root";
                string Query = "INSERT INTO sign_up (name, password) VALUES (@username, @password)";

                using (MySqlConnection MyConn2 = new MySqlConnection(MyConnection2))
                {
                    using (MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2))
                    {
                        MyCommand2.Parameters.AddWithValue("@username", textBox1.Text);
                        MyCommand2.Parameters.AddWithValue("@password", textBox2.Text);

                        MyConn2.Open();

                        int rowsAffected = MyCommand2.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Sign Up successful!");
                        }
                        else
                        {
                            MessageBox.Show("Sign Up failed. Please check your inputs.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }
    }
}

