﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SWE.Resources
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }

        private void guna2HtmlLabel12_Click(object sender, EventArgs e)
        {

        }
    }
}
